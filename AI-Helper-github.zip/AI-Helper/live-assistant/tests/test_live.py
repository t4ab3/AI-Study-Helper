"""Live assistant: phrase cutting, prompts, and the window's hint logic (bridge faked)."""

import os
import sys
import threading
import time
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from live_assistant.dialog import Dialog, clean_hint  # noqa: E402
from live_assistant.segmenter import RATE, Segmenter  # noqa: E402


def tone(sec, amp=0.2):
    t = np.arange(int(sec * RATE)) / RATE
    return (amp * np.sin(2 * np.pi * 220 * t)).astype(np.float32)


def quiet(sec):
    return (np.random.default_rng(1).normal(0, 0.001, int(sec * RATE))).astype(np.float32)


def feed_in_blocks(seg, audio, block=1600):
    out = []
    for i in range(0, len(audio), block):
        out += seg.feed(audio[i : i + block])
    return out


def test_phrases_are_cut_at_pauses_and_clicks_ignored():
    seg = Segmenter()
    audio = np.concatenate([quiet(1), tone(1.2), quiet(1.0), tone(0.1), quiet(1.0), tone(0.8), quiet(1.2)])
    phrases = feed_in_blocks(seg, audio)
    assert len(phrases) == 2  # the 0.1 s click is not a phrase
    assert 1.2 < len(phrases[0]) / RATE < 2.5  # with the pre-roll and the trailing pause


def test_a_short_breath_does_not_split_a_phrase_and_flush_keeps_the_tail():
    seg = Segmenter()
    phrases = feed_in_blocks(seg, np.concatenate([quiet(0.5), tone(1), quiet(0.4), tone(1)]))
    assert phrases == []
    tail = seg.flush()
    assert len(tail) == 1 and len(tail[0]) / RATE > 2


def test_prompts_carry_only_new_turns_and_my_lines_are_context():
    d = Dialog("ru", about="публичные выступления")
    d.add("them", "Как вы готовитесь к выступлению?")
    p1, new1 = d.prompt()
    assert new1 and "суфлёр" in p1 and "Язык разговора: русский" in p1 and "Тема разговора" in p1 and "публичные выступления" in p1
    assert "Собеседник: Как вы готовитесь" in p1
    d.add("hint", "Сначала я пишу план…")
    d.add("me", "Я всегда начинаю с плана речи.")
    d.add("them", "А сколько репетируете?")
    p2, new2 = d.prompt()
    assert not new2 and "суфлёр" not in p2
    assert "Я: Я всегда начинаю с плана речи." in p2 and "Собеседник: А сколько репетируете?" in p2
    assert "Как вы готовитесь" not in p2 and "Сначала я пишу план" not in p2  # no repeats, no hints
    pm, _ = d.prompt(more=True)
    assert "подробнее" in pm.lower()


def test_failed_prompt_is_resent_and_restart_recaps():
    d = Dialog("en")
    d.add("them", "Hello")
    d.prompt()
    d.add("them", "Tell me about you")
    d.prompt()
    d.rollback()
    p, _ = d.prompt()
    assert "Tell me about you" in p
    d.restart()
    d.add("them", "Why this job?")
    p, new = d.prompt()
    assert new and "Разговор до этого" in p and "Собеседник: Hello" in p and "Новые реплики:\nСобеседник: Why this job?" in p


def test_clean_hint():
    assert clean_hint("«Да, **конечно**.»") == "Да, конечно."


class FakeEngine:
    state = "ready"
    message = ""

    def start_loading(self):
        pass

    def transcribe(self, audio, language=None):
        return []


def test_window_hints_after_every_phrase_and_queues_while_busy(monkeypatch, tmp_path):
    from PySide6.QtWidgets import QApplication

    from live_assistant import app as live_app
    from live_assistant import bridge_client

    qapp = QApplication.instance() or QApplication([])
    asked, release = [], threading.Event()

    def fake_ask(prompt, new_chat, settle=2.0):
        asked.append(prompt)
        release.wait(5)
        return f"Ответ {len(asked)}"

    monkeypatch.setattr(bridge_client, "ask", fake_ask)
    monkeypatch.setattr(bridge_client, "partial", lambda: {"id": 0, "text": "", "done": True})
    monkeypatch.setattr(bridge_client, "call", lambda *a, **k: {"id": 0, "text": ""})
    monkeypatch.setattr(bridge_client, "health", lambda: {"version": "test"})
    monkeypatch.setattr(live_app, "DIALOGS", tmp_path)
    monkeypatch.setattr(live_app, "hotkey_thread", lambda bus: None)
    w = live_app.Window(FakeEngine())

    def pump(until, timeout=5):
        end = time.time() + timeout
        while not until() and time.time() < end:
            qapp.processEvents()
            time.sleep(0.02)
        return until()

    w._on_text("them", "Первый вопрос?")
    w._on_text("me", "Отвечаю сам.")
    w._on_text("them", "Второй вопрос?")  # while the first hint is being written
    assert pump(lambda: len(asked) == 1)
    release.set()
    assert pump(lambda: len(asked) == 2 and not w.asking)
    assert "Второй вопрос?" in asked[1] and "Я: Отвечаю сам." in asked[1] and "Первый вопрос?" not in asked[1]
    hints = [t.text for t in w.dialog.turns if t.who == "hint"]
    assert hints == ["Ответ 1", "Ответ 2"]
    # my own phrase alone never asks for a hint
    w._on_text("me", "Ещё моя фраза.")
    assert pump(lambda: True) and len(asked) == 2
    w.clear()
    saved = list(tmp_path.glob("*.txt"))
    assert len(saved) == 1 and "Собеседник: Второй вопрос?" in saved[0].read_text(encoding="utf-8")
    w.listener.stop()
    w.deleteLater()


def test_startup_launches_bridge_and_opens_deepseek(monkeypatch):
    from PySide6.QtWidgets import QApplication

    from live_assistant import app as live_app
    from live_assistant import bridge_client

    qapp = QApplication.instance() or QApplication([])
    state = {"up": False, "checked": 0}

    def health():
        if not state["up"]:
            raise bridge_client.BridgeError("offline", "нет")
        return {"version": "test"}

    def check():
        state["checked"] += 1
        return {"ready": True}

    monkeypatch.setattr(bridge_client, "health", health)
    monkeypatch.setattr(bridge_client, "check", check)
    monkeypatch.setattr(live_app.Window, "_launch_bridge", staticmethod(lambda: state.update(up=True)))
    monkeypatch.setattr(live_app, "hotkey_thread", lambda bus: None)
    w = live_app.Window(FakeEngine())
    end = time.time() + 6
    while "DeepSeek готов" not in w.status.text() and time.time() < end:
        qapp.processEvents()
        time.sleep(0.02)
    assert state["checked"] == 1 and "DeepSeek готов" in w.status.text()
    w.listener.stop()
    w.deleteLater()
