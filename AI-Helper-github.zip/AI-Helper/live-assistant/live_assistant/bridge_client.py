"""The DeepSeek bridge over HTTP (the same bridge the Chrome extension uses)."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

PORT = int(os.environ.get("AITS_PORT", "8765"))
HEADERS = {"X-AITS-Client": "ai-test-solver", "Content-Type": "application/json"}


class BridgeError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def call(path: str, method: str = "GET", body: dict | None = None, timeout: float = 10.0, port: int = PORT) -> dict:
    data = json.dumps(body or {}).encode("utf-8") if method == "POST" else None
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data, method=method, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read() or b"{}").get("error", {})
        except ValueError:
            err = {}
        raise BridgeError(err.get("code", f"http_{e.code}"), err.get("message", f"Ошибка bridge {e.code}")) from e
    except (urllib.error.URLError, OSError) as e:
        raise BridgeError("offline", "Bridge не запущен. Запустите ярлык «AI Helper (bridge)».") from e


def health() -> dict:
    return call("/health", timeout=2)


def check() -> dict:
    return call("/deepseek/check", "POST", timeout=120)


def signup() -> dict:
    return call("/deepseek/signup", "POST", timeout=30)


def ask(prompt: str, new_chat: bool, settle: float = 2.0) -> str:
    return call("/deepseek/ask", "POST", {"prompt": prompt, "new_chat": new_chat, "settle": settle, "timeout": 120}, timeout=150)["text"]


def partial() -> dict:
    return call("/deepseek/partial", timeout=2)
