"""Cuts a stream of audio into phrases at pauses.

Energy based, with a noise floor that follows the room: a phrase starts when the level rises well
above the floor and ends after `end_silence` seconds of quiet. Whisper's own voice filter then
drops whatever is not speech, so this only has to find the pauses.
"""

from __future__ import annotations

from collections import deque

import numpy as np

RATE = 16_000
FRAME = 480  # 30 ms


class Segmenter:
    def __init__(
        self,
        end_silence: float = 0.8,
        min_speech: float = 0.35,
        max_phrase: float = 20.0,
        pre_roll: float = 0.3,
        threshold: float = 0.012,
    ):
        self.end_frames = int(end_silence * RATE / FRAME)
        self.min_frames = int(min_speech * RATE / FRAME)
        self.max_frames = int(max_phrase * RATE / FRAME)
        self.threshold = threshold  # absolute minimum level that counts as voice
        self.noise = threshold / 3
        self._pre: deque = deque(maxlen=max(1, int(pre_roll * RATE / FRAME)))
        self._buf = np.zeros(0, dtype=np.float32)
        self._phrase: list = []
        self._voiced = 0
        self._quiet = 0
        self.level = 0.0  # last frame's level, for the meter

    def feed(self, audio: np.ndarray) -> list:
        """audio: float32 mono 16 kHz. Returns the phrases that ended in it."""
        out = []
        self._buf = np.concatenate([self._buf, audio.astype(np.float32).reshape(-1)])
        n = len(self._buf) // FRAME
        for i in range(n):
            frame = self._buf[i * FRAME : (i + 1) * FRAME]
            level = float(np.sqrt(np.mean(frame * frame)))
            self.level = level
            loud = level > max(self.threshold, self.noise * 3)
            if not self._phrase:
                if loud:
                    self._phrase = list(self._pre)
                    self._phrase.append(frame)
                    self._voiced, self._quiet = 1, 0
                else:
                    # the floor follows quiet frames only, so speech never raises it
                    self.noise = 0.95 * self.noise + 0.05 * level
                    self._pre.append(frame)
                continue
            self._phrase.append(frame)
            if loud:
                self._voiced += 1
                self._quiet = 0
            else:
                self._quiet += 1
            if self._quiet >= self.end_frames or len(self._phrase) >= self.max_frames:
                if self._voiced >= self.min_frames:
                    out.append(np.concatenate(self._phrase))
                self._phrase, self._voiced, self._quiet = [], 0, 0
                self._pre.clear()
        self._buf = self._buf[n * FRAME :]
        return out

    def flush(self) -> list:
        """The phrase still being spoken (when listening stops)."""
        out = [np.concatenate(self._phrase)] if self._phrase and self._voiced >= self.min_frames else []
        self._phrase, self._voiced, self._quiet = [], 0, 0
        return out
