"""python -m live_assistant (run from the live-assistant folder, with the bridge's Python)."""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "bridge"))  # the Whisper engine is shared with the bridge


def main() -> int:
    logs = ROOT / "logs"
    logs.mkdir(exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        handlers=[RotatingFileHandler(logs / "live.log", maxBytes=1_000_000, backupCount=2, encoding="utf-8")],
    )
    from PySide6.QtWidgets import QApplication

    from deepseek_bridge.transcriber import Engine

    from .app import Window

    app = QApplication(sys.argv)
    app.setApplicationName("AI Helper Live")
    w = Window(Engine())
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
