"""The conversation and the prompts for DeepSeek.

Two speakers: "them" (the computer's sound: the other person) and "me" (the microphone). After
every phrase of theirs DeepSeek writes a short line for me to say. My own phrases are only kept in
the history, so the next hint builds on what I really said.

One DeepSeek chat holds the conversation; each prompt carries only what is new since the last
one. Every NEW_CHAT_EVERY prompts a fresh chat starts with the instructions and a recap, so the
page does not grow without end.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

LANG_NAMES = {"uk": "українська", "ru": "русский", "en": "English"}
NEW_CHAT_EVERY = 25
RECAP_TURNS = 16

INSTRUCTIONS = """Ты — мой суфлёр в живом разговоре. Я говорю вслух, и мне нужна реплика, которую я сразу произнесу.

Тебе будут приходить реплики двух сторон, распознанные из звука (в них бывают ошибки — понимай по смыслу):
- «Собеседник:» — то, что говорит другой человек. На его последнюю реплику дай мне ответ.
- «Я:» — то, что я уже сказал сам. На это не отвечай. Просто учитывай: не повторяй это, не противоречь этому и опирайся на это дальше.

Как отвечать:
- от первого лица, как будто говорю я, простой живой разговорной речью, по-человечески;
- 2–3 коротких предложения строго по сути вопроса, без вступлений вроде «Отличный вопрос»;
- никаких списков, заголовков, markdown и пояснений для меня — только сама реплика;
- если собеседник просит подробнее или уточняет — ответь подробнее, 4–6 предложений;
- если реплика собеседника не вопрос — всё равно дай короткую уместную реплику в ответ.

Язык разговора: {lang}. Отвечай на нём."""

ABOUT = "\n\nТема разговора (учитывай её в ответах): {about}"
REMINDER = "(Ответь мне репликой на последнюю фразу собеседника: 2–3 предложения, от первого лица, живой речью.)"
MORE = (
    "Собеседник хочет подробнее. Разверни свою последнюю подсказку: 4–6 предложений, всё так же от первого лица "
    "и живой разговорной речью, без списков."
)


@dataclass
class Turn:
    who: str  # "them" | "me" | "hint"
    text: str
    t: float = field(default_factory=time.time)


def _line(t: Turn) -> str:
    return f"{'Собеседник' if t.who == 'them' else 'Я'}: {t.text}"


class Dialog:
    def __init__(self, language: str = "ru", about: str = ""):
        self.language = language
        self.about = about.strip()
        self.turns: list[Turn] = []
        self._sent = 0  # turns[:_sent] are already in the DeepSeek chat
        self._asks = 0

    def add(self, who: str, text: str) -> Turn:
        turn = Turn(who, text.strip())
        self.turns.append(turn)
        return turn

    def _header(self) -> str:
        head = INSTRUCTIONS.format(lang=LANG_NAMES.get(self.language, self.language))
        return head + (ABOUT.format(about=self.about[:4000]) if self.about else "")

    def prompt(self, more: bool = False) -> tuple[str, bool]:
        """(prompt, new_chat) for the next hint. Marks the turns as sent."""
        self._undo = (self._sent, self._asks)
        new_chat = self._asks % NEW_CHAT_EVERY == 0
        if new_chat:
            # the recap: earlier turns, so a fresh chat still knows the conversation
            fresh = [t for t in self.turns[self._sent :] if t.who != "hint"]
            old = [t for t in self.turns[: self._sent] if t.who != "hint"][-RECAP_TURNS:]
            parts = [self._header()]
            if old:
                parts.append("Разговор до этого:\n" + "\n".join(map(_line, old)))
            body = "\n".join(map(_line, fresh))
            parts.append(("Новые реплики:\n" + body) if body else "")
        else:
            body = "\n".join(_line(t) for t in self.turns[self._sent :] if t.who != "hint")
            parts = [("Новые реплики:\n" + body) if body else ""]
        parts.append(MORE if more else REMINDER)
        self._sent = len(self.turns)
        self._asks += 1
        return "\n\n".join(p for p in parts if p), new_chat

    def rollback(self) -> None:
        """The last prompt did not reach DeepSeek: its phrases go with the next one."""
        self._sent, self._asks = getattr(self, "_undo", (self._sent, self._asks))

    def restart(self) -> None:
        """The next prompt opens a new chat (language or the file about me changed)."""
        self._asks = 0

    def text(self) -> str:
        """The conversation for the saved file."""
        names = {"them": "Собеседник", "me": "Я", "hint": "Подсказка"}
        return "\n".join(f"[{time.strftime('%H:%M:%S', time.localtime(t.t))}] {names[t.who]}: {t.text}" for t in self.turns)


def clean_hint(text: str) -> str:
    """DeepSeek sometimes wraps the line in quotes or adds markdown; the person reads it aloud."""
    t = text.strip()
    for a, b in (("«", "»"), ('"', '"'), ("“", "”")):
        if len(t) > 2 and t.startswith(a) and t.endswith(b):
            t = t[1:-1].strip()
    return t.replace("**", "").replace("__", "")
