"""The live assistant window: the conversation, the hint, the settings."""

from __future__ import annotations

import ctypes
import html
import logging
import sys
import threading
import time
from ctypes import wintypes
from pathlib import Path

from PySide6.QtCore import QObject, QPoint, QSettings, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QSlider,
    QSpinBox,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from . import audio, bridge_client
from .dialog import LANG_NAMES, Dialog, clean_hint

log = logging.getLogger("live.app")
ROOT = Path(__file__).resolve().parents[2]
DIALOGS = ROOT / "Диалоги"
EDGE = 8  # px at the border that resize the frameless window
WDA_EXCLUDEFROMCAPTURE = 0x11
HOTKEY_MORE = "Ctrl+Alt+D"

WAIT_CODES = {
    "login_required": "Войдите в DeepSeek: ⚙ → «Вход / регистрация».",
    "captcha": "DeepSeek просит пройти проверку: пройдите её в окне DeepSeek или нажмите ⚙ → «Вход / регистрация».",
    "signup_window_open": "Открыто окно входа в DeepSeek. Закончите вход и закройте его.",
    "offline": "Bridge не запущен: ⚙ → «Запустить bridge».",
}


class Bus(QObject):
    text = Signal(str, str)
    error = Signal(str, str)
    status = Signal(str)
    hint_done = Signal(str)
    hint_failed = Signal(str, str)
    hotkey = Signal()


def set_capture_hidden(hwnd: int, hidden: bool) -> bool:
    """Windows 10 2004+: screen sharing and screenshots show what is under the window."""
    if sys.platform != "win32":
        return False
    return bool(ctypes.windll.user32.SetWindowDisplayAffinity(wintypes.HWND(hwnd), WDA_EXCLUDEFROMCAPTURE if hidden else 0))


def hotkey_thread(bus: Bus) -> None:
    """Global Ctrl+Alt+D → «Подробнее», also while another program has the focus."""
    if sys.platform != "win32":
        return
    user32 = ctypes.windll.user32
    if not user32.RegisterHotKey(None, 1, 0x0001 | 0x0002 | 0x4000, ord("D")):  # Alt | Ctrl | NoRepeat
        log.warning("hotkey %s is taken by another program", HOTKEY_MORE)
        return
    msg = wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        if msg.message == 0x0312:  # WM_HOTKEY
            bus.hotkey.emit()


class Window(QWidget):
    def __init__(self, engine) -> None:
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setMouseTracking(True)
        self.setWindowTitle("AI Helper Live")
        self.engine = engine
        self.cfg = QSettings("AIHelper", "Live")
        self.bus = Bus()
        lang = str(self.cfg.value("language", "ru"))
        self.dialog = Dialog(lang if lang in LANG_NAMES else "ru", str(self.cfg.value("topic", "")))
        self.listener = audio.Listener(self._transcribe, self.bus.text.emit, self.bus.error.emit)
        self.listening = False
        self.asking = False
        self.pending: bool | None = None  # another hint was asked for while one is being written
        self.hint_turn = None
        self.base_id = 0
        self.saved_upto = 0

        self._build()
        self.bus.text.connect(self._on_text)
        self.bus.error.connect(lambda who, msg: self._status(msg))
        self.bus.status.connect(self._status)
        self.bus.hint_done.connect(self._hint_done)
        self.bus.hint_failed.connect(self._hint_failed)
        self.bus.hotkey.connect(lambda: self.ask(more=True))
        threading.Thread(target=hotkey_thread, args=(self.bus,), daemon=True, name="hotkey").start()

        self.poll = QTimer(self, interval=300, timeout=self._poll_partial)
        self.meters = QTimer(self, interval=120, timeout=self._update_meters)
        self.meters.start()
        self.engine.start_loading()
        QTimer.singleShot(200, self._startup_check)

        g = self.cfg.value("geometry")
        if g:
            self.restoreGeometry(g)
        else:
            scr = QGuiApplication.primaryScreen().availableGeometry()
            self.setGeometry(scr.right() - 460, scr.top() + 80, 440, 560)

    # ---------------------------------------------------------------- UI
    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(EDGE + 4, EDGE, EDGE + 4, EDGE + 4)
        root.setSpacing(6)

        head = QHBoxLayout()
        self.title = QLabel("AI Helper Live")
        self.title.setStyleSheet("font-weight: 600;")
        self.listen_btn = QPushButton("▶ Слушать", clicked=self.toggle_listen)
        self.more_btn = QPushButton("Подробнее", clicked=lambda: self.ask(more=True))
        self.more_btn.setToolTip(f"Развернуть последнюю подсказку ({HOTKEY_MORE} — из любой программы)")
        self.clear_btn = QPushButton("Очистить", clicked=self.clear)
        self.gear_btn = QPushButton("⚙", clicked=lambda: self.settings.setVisible(not self.settings.isVisible()))
        self.close_btn = QPushButton("✕", clicked=self.close)
        for b in (self.gear_btn, self.close_btn):
            b.setFixedWidth(30)
        head.addWidget(self.title)
        head.addStretch(1)
        for b in (self.listen_btn, self.more_btn, self.clear_btn, self.gear_btn, self.close_btn):
            head.addWidget(b)
        root.addLayout(head)

        meters = QHBoxLayout()
        self.meter_them, self.meter_me = QProgressBar(), QProgressBar()
        for label, bar in (("Собеседник", self.meter_them), ("Я", self.meter_me)):
            bar.setRange(0, 100)
            bar.setTextVisible(False)
            bar.setFixedHeight(6)
            meters.addWidget(QLabel(label))
            meters.addWidget(bar, 1)
        root.addLayout(meters)

        self.view = QTextBrowser()
        self.view.setOpenLinks(False)
        root.addWidget(self.view, 1)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setStyleSheet("color: #222; font-size: 11px;")
        root.addWidget(self.status)

        self.settings = QFrame()
        self.settings.setVisible(False)
        form = QFormLayout(self.settings)
        form.setContentsMargins(0, 4, 0, 0)
        self.lang = QComboBox()
        for code, name in LANG_NAMES.items():
            self.lang.addItem(name, code)
        self.lang.setCurrentIndex(max(0, self.lang.findData(self.dialog.language)))
        self.lang.currentIndexChanged.connect(self._lang_changed)
        form.addRow("Язык разговора", self.lang)
        self.spk = QComboBox()
        self.mic = QComboBox()
        self._fill_devices()
        form.addRow("Звук собеседника", self.spk)
        form.addRow("Мой микрофон", self.mic)
        self.alpha = QSlider(Qt.Orientation.Horizontal, minimum=10, maximum=95, value=int(self.cfg.value("alpha", 55)))
        self.alpha.valueChanged.connect(self._style_changed)
        form.addRow("Непрозрачность фона", self.alpha)
        self.font = QSpinBox(minimum=10, maximum=30, value=int(self.cfg.value("font", 15)))
        self.font.valueChanged.connect(self._style_changed)
        form.addRow("Размер текста", self.font)
        self.hide_cap = QCheckBox("Скрыть от демонстрации экрана")
        self.hide_cap.setToolTip("Zoom, Teams, Meet, Discord, OBS и скриншоты покажут вместо окна то, что под ним")
        self.hide_cap.setChecked(self.cfg.value("hide_capture", "true") in (True, "true"))
        self.hide_cap.toggled.connect(self._apply_capture)
        form.addRow(self.hide_cap)
        self.topic = QLineEdit(str(self.cfg.value("topic", "")))
        self.topic.setPlaceholderText("например: физика, веб-технологии")
        self.topic.setClearButtonEnabled(True)
        self.topic.textChanged.connect(self._set_topic)  # also catches the ✕ clear button
        form.addRow("Тема разговора", self.topic)
        ds = QHBoxLayout()
        ds.addWidget(QPushButton("Проверить DeepSeek", clicked=self._check_deepseek))
        ds.addWidget(QPushButton("Вход / регистрация", clicked=self._signup))
        form.addRow("DeepSeek", ds)
        form.addRow("Bridge", QPushButton("Запустить bridge", clicked=self._start_bridge))
        root.addWidget(self.settings)
        self._style_changed()
        self._render()

    def _fill_devices(self) -> None:
        for combo, names, key in ((self.spk, audio.speakers, "speaker"), (self.mic, audio.microphones, "mic")):
            combo.addItem("По умолчанию (как в Windows)", "")
            try:
                for n in names():
                    combo.addItem(n, n)
            except Exception as e:  # noqa: BLE001
                log.warning("device list failed: %s", e)
            combo.setCurrentIndex(max(0, combo.findData(str(self.cfg.value(key, "")))))
            # long device names must not widen the window
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            combo.setMinimumContentsLength(12)

    def _style_changed(self) -> None:
        self.cfg.setValue("alpha", self.alpha.value())
        self.cfg.setValue("font", self.font.value())
        fs = self.font.value()
        self.setStyleSheet(
            "QWidget { color: #000; font-family: 'Segoe UI'; font-size: 12px; }"
            "QPushButton { background: rgba(255,255,255,0.55); border: 1px solid rgba(0,0,0,0.25); border-radius: 5px; padding: 3px 8px; }"
            "QPushButton:hover { background: rgba(255,255,255,0.8); }"
            "QComboBox, QSpinBox { background: rgba(255,255,255,0.7); }"
            "QProgressBar { background: rgba(0,0,0,0.3); border: none; border-radius: 3px; }"
            "QProgressBar::chunk { background: #2e7d32; border-radius: 3px; }"
            f"QTextBrowser {{ background: transparent; border: none; font-size: {fs}px; }}"
        )
        self.update()

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setBrush(QColor(205, 205, 205, int(self.alpha.value() * 2.55)))
        p.setPen(QPen(QColor(0, 0, 0, 70), 1))
        p.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), 10, 10)

    def _render(self) -> None:
        bar = self.view.verticalScrollBar()
        at_end = bar.value() >= bar.maximum() - 4
        rows = []
        for t in self.dialog.turns:
            text = html.escape(t.text).replace("\n", "<br>")
            if t.who == "them":
                rows.append(f"<p style='margin:4px 0'><b>Собеседник:</b> {text}</p>")
            elif t.who == "me":
                rows.append(f"<p style='margin:4px 0; color:#333'><b>Я:</b> <i>{text}</i></p>")
            else:
                rows.append(
                    "<table width='100%' cellpadding='6' style='margin:4px 0 10px 0; background: rgba(255,255,255,0.55)'>"
                    f"<tr><td><b>➜ {text}</b></td></tr></table>"
                )
        if not rows:
            rows.append(
                "<p style='color:#333'>Нажмите «▶ Слушать». Слева сверху уровни звука: собеседник — звук компьютера, "
                "я — микрофон. После каждой фразы собеседника здесь появится подсказка.</p>"
            )
        self.view.setHtml("".join(rows))
        if at_end:
            bar.setValue(bar.maximum())

    def _status(self, msg: str) -> None:
        self.status.setText(msg)

    def _update_meters(self) -> None:
        for who, bar in (("them", self.meter_them), ("me", self.meter_me)):
            bar.setValue(min(100, int((self.listener.level(who) ** 0.5) * 300)))
        if self.engine.state == "loading":
            self._status(self.engine.message)

    # ---------------------------------------------------------------- window behaviour
    def showEvent(self, e) -> None:  # noqa: N802
        super().showEvent(e)
        self._apply_capture()

    def _apply_capture(self) -> None:
        on = self.hide_cap.isChecked()
        self.cfg.setValue("hide_capture", on)
        if not set_capture_hidden(int(self.winId()), on) and on:
            self._status("Скрыть окно от демонстрации не получилось: нужна Windows 10 версии 2004 или новее.")

    def _edges(self, pos: QPoint) -> Qt.Edge:
        e = Qt.Edge(0)
        if pos.x() <= EDGE:
            e |= Qt.Edge.LeftEdge
        if pos.x() >= self.width() - EDGE:
            e |= Qt.Edge.RightEdge
        if pos.y() <= EDGE:
            e |= Qt.Edge.TopEdge
        if pos.y() >= self.height() - EDGE:
            e |= Qt.Edge.BottomEdge
        return e

    def mousePressEvent(self, e) -> None:  # noqa: N802
        if e.button() != Qt.MouseButton.LeftButton:
            return
        edges = self._edges(e.position().toPoint())
        h = self.windowHandle()
        if edges:
            h.startSystemResize(edges)
        else:
            h.startSystemMove()

    def mouseMoveEvent(self, e) -> None:  # noqa: N802
        edges = self._edges(e.position().toPoint())
        horiz = bool(edges & (Qt.Edge.LeftEdge | Qt.Edge.RightEdge))
        vert = bool(edges & (Qt.Edge.TopEdge | Qt.Edge.BottomEdge))
        diag_main = edges in (Qt.Edge.LeftEdge | Qt.Edge.TopEdge, Qt.Edge.RightEdge | Qt.Edge.BottomEdge)
        if horiz and vert:
            self.setCursor(Qt.CursorShape.SizeFDiagCursor if diag_main else Qt.CursorShape.SizeBDiagCursor)
        elif horiz:
            self.setCursor(Qt.CursorShape.SizeHorCursor)
        elif vert:
            self.setCursor(Qt.CursorShape.SizeVerCursor)
        else:
            self.setCursor(Qt.CursorShape.ArrowCursor)

    def closeEvent(self, e) -> None:  # noqa: N802
        self.listener.stop()
        self.save_dialog()
        self.cfg.setValue("geometry", self.saveGeometry())
        super().closeEvent(e)
        QApplication.quit()

    # ---------------------------------------------------------------- settings
    def _set_topic(self) -> None:
        topic = self.topic.text().strip()
        if topic == self.dialog.about:
            return
        self.cfg.setValue("topic", topic)
        self.dialog.about = topic
        self.dialog.restart()  # the next hint starts a new chat that carries the topic

    def _lang_changed(self) -> None:
        self.dialog.language = self.lang.currentData()
        self.cfg.setValue("language", self.dialog.language)
        self.dialog.restart()

    # ---------------------------------------------------------------- listening
    def _transcribe(self, audio_data) -> str:
        return " ".join(s.text for s in self.engine.transcribe(audio_data, language=self.dialog.language))

    def toggle_listen(self) -> None:
        if self.listening:
            self.listener.stop()
            self.listening = False
            self.listen_btn.setText("▶ Слушать")
            self._status("Пауза. Разговор сохранён в окне.")
            return
        self.cfg.setValue("speaker", self.spk.currentData())
        self.cfg.setValue("mic", self.mic.currentData())
        self.listener.start(self.spk.currentData(), self.mic.currentData())
        self.listening = True
        self.listen_btn.setText("⏸ Пауза")
        self._status("Слушаю." if self.engine.state == "ready" else self.engine.message)

    def _on_text(self, who: str, text: str) -> None:
        self.dialog.add(who, text)
        self._render()
        if who == "them":
            self.ask(more=False)

    # ---------------------------------------------------------------- hints
    def ask(self, more: bool) -> None:
        if not any(t.who == "them" for t in self.dialog.turns):
            return
        if self.asking:
            # after the current hint, one more that also covers what was said meanwhile
            self.pending = bool(self.pending) or more
            return
        prompt, new_chat = self.dialog.prompt(more)
        self.hint_turn = self.dialog.add("hint", "…")
        self.asking = True
        self._render()

        def work() -> None:
            try:
                try:
                    self.base_id = int(bridge_client.partial().get("id", 0))
                except bridge_client.BridgeError:
                    self.base_id = 0
                self.bus.hint_done.emit(bridge_client.ask(prompt, new_chat))
            except bridge_client.BridgeError as e:
                self.bus.hint_failed.emit(e.code, e.message)
            except Exception as e:  # noqa: BLE001
                log.exception("ask failed")
                self.bus.hint_failed.emit("error", str(e))

        threading.Thread(target=work, daemon=True, name="ask").start()
        self.poll.start()

    def _poll_partial(self) -> None:
        if not self.asking or not self.hint_turn:
            return
        try:
            p = bridge_client.call("/deepseek/partial", timeout=0.5)
        except bridge_client.BridgeError:
            return
        if int(p.get("id", 0)) > self.base_id and p.get("text"):
            self.hint_turn.text = clean_hint(p["text"])
            self._render()

    def _finish(self) -> None:
        self.asking = False
        self.poll.stop()
        if self.pending is not None:
            more, self.pending = self.pending, None
            self.ask(more)

    def _hint_done(self, text: str) -> None:
        if self.hint_turn:
            self.hint_turn.text = clean_hint(text)
        self._render()
        self._status("Слушаю." if self.listening else "")
        self._finish()

    def _hint_failed(self, code: str, msg: str) -> None:
        self.dialog.rollback()  # those phrases go with the next prompt
        if self.hint_turn:
            self.hint_turn.text = "⚠ " + WAIT_CODES.get(code, msg)
        self._render()
        self._status(WAIT_CODES.get(code, msg))
        self.pending = None
        self._finish()

    # ---------------------------------------------------------------- DeepSeek and bridge
    def _bg(self, fn) -> None:
        def run() -> None:
            try:
                self.bus.status.emit(fn())
            except bridge_client.BridgeError as e:
                self.bus.status.emit(WAIT_CODES.get(e.code, e.message))

        threading.Thread(target=run, daemon=True).start()

    def _startup_check(self, started: bool = False) -> None:
        """Opens DeepSeek right away, so the first hint does not wait for the browser to start."""

        def f() -> str:
            try:
                bridge_client.health()
            except bridge_client.BridgeError as e:
                if e.code != "offline" or started:
                    raise
                self.bus.status.emit("Bridge не запущен, запускаю…")
                self._launch_bridge()
                for _ in range(30):  # the bridge needs a few seconds (Whisper, Chrome)
                    time.sleep(1)
                    try:
                        bridge_client.health()
                        break
                    except bridge_client.BridgeError:
                        pass
                else:
                    raise
            self.bus.status.emit("Открываю DeepSeek…")
            st = bridge_client.check()  # starts the DeepSeek browser if it is not open yet
            if st.get("ready"):
                return "DeepSeek готов. Нажмите «▶ Слушать»."
            return WAIT_CODES.get(st.get("reason") or "", st.get("message", "DeepSeek не готов."))

        self._bg(f)

    def _check_deepseek(self) -> None:
        self._status("Проверяю DeepSeek…")

        def f() -> str:
            st = bridge_client.check()
            return "DeepSeek готов." if st.get("ready") else WAIT_CODES.get(st.get("reason") or "", st.get("message", ""))

        self._bg(f)

    def _signup(self) -> None:
        def f() -> str:
            r = bridge_client.signup()
            return ("Окно входа уже открыто." if r.get("action") == "already_open" else "Открыл DeepSeek в обычном окне Chrome.") + (
                " Войдите или зарегистрируйтесь и закройте это окно."
            )

        self._bg(f)

    @staticmethod
    def _launch_bridge() -> None:
        import os

        os.startfile(str(ROOT / "bridge" / "start_bridge.bat"))  # noqa: S606 - our own launcher

    def _start_bridge(self) -> None:
        try:
            self._launch_bridge()
            self._status("Запускаю bridge…")
            QTimer.singleShot(6000, lambda: self._startup_check(started=True))
        except OSError as e:
            self._status(f"Не удалось запустить bridge: {e}")

    # ---------------------------------------------------------------- saving
    def save_dialog(self) -> None:
        spoken = [t for t in self.dialog.turns if t.who != "hint"]
        if not spoken:
            return
        DIALOGS.mkdir(parents=True, exist_ok=True)
        if not getattr(self, "_file", None):
            self._file = DIALOGS / f"{time.strftime('%Y-%m-%d %H-%M-%S')}.txt"
        self._file.write_text(self.dialog.text(), encoding="utf-8")
        log.info("dialog saved to %s", self._file)

    def clear(self) -> None:
        self.save_dialog()
        self._file = None
        self.dialog = Dialog(self.dialog.language, self.dialog.about)
        self.hint_turn = None
        self._render()
        self._status("Новый разговор. Прошлый сохранён в папке «Диалоги».")
