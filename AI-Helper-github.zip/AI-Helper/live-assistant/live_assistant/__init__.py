"""AI Helper Live: hints for a live conversation from the computer's sound and the microphone."""
