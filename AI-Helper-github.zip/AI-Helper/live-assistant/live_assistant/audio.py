"""Two sound sources: the computer's sound (the other person, WASAPI loopback) and the microphone.

Each source runs in its own thread, cuts its sound into phrases and puts (who, audio) into one
queue. A single worker transcribes them in order, so the GPU is used by one phrase at a time.
"""

from __future__ import annotations

import logging
import queue
import threading
from typing import Callable, Optional

import numpy as np

from .segmenter import RATE, Segmenter

log = logging.getLogger("live.audio")
BLOCK = RATE // 10  # 100 ms


def speakers() -> list[str]:
    import soundcard as sc

    return [s.name for s in sc.all_speakers()]


def microphones() -> list[str]:
    import soundcard as sc

    return [m.name for m in sc.all_microphones()]


def _open(who: str, device: str):
    import soundcard as sc

    if who == "them":
        name = device or sc.default_speaker().name
        return sc.get_microphone(id=str(name), include_loopback=True)
    return sc.get_microphone(id=str(device)) if device else sc.default_microphone()


class Source(threading.Thread):
    def __init__(self, who: str, device: str, out: "queue.Queue", on_error: Callable[[str, str], None]):
        super().__init__(name=f"audio-{who}", daemon=True)
        self.who, self.device, self.out, self.on_error = who, device, out, on_error
        self.stop_event = threading.Event()
        self.seg = Segmenter()

    @property
    def level(self) -> float:
        return self.seg.level

    def run(self) -> None:
        try:
            mic = _open(self.who, self.device)
            with mic.recorder(samplerate=RATE, channels=1, blocksize=BLOCK) as rec:
                log.info("%s: listening to %s", self.who, mic.name)
                while not self.stop_event.is_set():
                    block = rec.record(numframes=BLOCK)
                    mono = block.mean(axis=1) if block.ndim == 2 else block
                    for phrase in self.seg.feed(mono.astype(np.float32)):
                        self.out.put((self.who, phrase))
            for phrase in self.seg.flush():
                self.out.put((self.who, phrase))
        except Exception as e:  # noqa: BLE001
            log.exception("%s source failed", self.who)
            what = "звук компьютера" if self.who == "them" else "микрофон"
            self.on_error(self.who, f"Не удалось слушать {what}: {e}")

    def stop(self) -> None:
        self.stop_event.set()


class Listener:
    """Both sources plus the transcription worker. on_text(who, text) is called from the worker."""

    def __init__(self, transcribe: Callable[[np.ndarray], str], on_text: Callable[[str, str], None], on_error: Callable[[str, str], None]):
        self.transcribe, self.on_text, self.on_error = transcribe, on_text, on_error
        self.q: "queue.Queue" = queue.Queue()
        self.sources: dict[str, Source] = {}
        self._worker: Optional[threading.Thread] = None

    def start(self, speaker: str = "", mic: str = "") -> None:
        self.stop()
        self.sources = {"them": Source("them", speaker, self.q, self.on_error), "me": Source("me", mic, self.q, self.on_error)}
        for s in self.sources.values():
            s.start()
        if not self._worker or not self._worker.is_alive():
            self._worker = threading.Thread(target=self._work, name="transcribe", daemon=True)
            self._worker.start()

    def stop(self) -> None:
        for s in self.sources.values():
            s.stop()
        self.sources = {}

    def level(self, who: str) -> float:
        s = self.sources.get(who)
        return s.level if s else 0.0

    def _work(self) -> None:
        while True:
            who, audio = self.q.get()
            try:
                text = self.transcribe(audio).strip()
            except Exception as e:  # noqa: BLE001
                log.exception("transcription failed")
                self.on_error(who, f"Ошибка распознавания: {e}")
                continue
            if text:
                self.on_text(who, text)
